#include <iostream>
using namespace std;

int main() {
    const int correctPin = 1234;
    double balance = 1000.00; // Initial balance
    int pin;
    int choice;
    double amount;

    // Login
    cout << "Welcome to the ATM.\nEnter your 4-digit PIN: ";
    cin >> pin;

    if (pin != correctPin) {
        cout << "Incorrect PIN. Exiting...\n";
        return 0;
    }

    cout << "Login successful.\n";

    // Main menu loop
    do {
        cout << "\n--- ATM Menu ---\n";
        cout << "1. View Balance\n";
        cout << "2. Withdraw\n";
        cout << "3. Deposit\n";
        cout << "4. Log Out\n";
        cout << "Choose an option: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Current balance: $" << balance << "\n";
                break;

            case 2:
                cout << "Enter amount to withdraw: $";
                cin >> amount;
                if (amount <= 0) {
                    cout << "Invalid amount.\n";
                } else if (amount > balance) {
                    cout << "Insufficient funds.\n";
                } else {
                    balance -= amount;
                    cout << "Withdrawal successful. New balance: $" << balance << "\n";
                }
                break;

            case 3:
                cout << "Enter amount to deposit: $";
                cin >> amount;
                if (amount <= 0) {
                    cout << "Invalid amount.\n";
                } else {
                    balance += amount;
                    cout << "Deposit successful. New balance: $" << balance << "\n";
                }
                break;

            case 4:
                cout << "Logging out. Thank you!\n";
                break;

            default:
                cout << "Invalid option. Please try again.\n";
                break;
        }

    } while (choice != 4);

    return 0;
}
