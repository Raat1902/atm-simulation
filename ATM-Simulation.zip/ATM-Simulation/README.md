# Basic ATM Simulation in C++

## Description
This is a simple console-based ATM simulation written in C++. It allows users to:

- Log in using a PIN
- View account balance
- Withdraw money
- Deposit money
- Log out

## Features
- Input validation
- Loop-based menu system
- Easily extendable for multiple users or transactions

## How to Run

1. **Compile** the code:
   ```bash
   g++ main.cpp -o atm
   ```

2. **Run** the executable:
   ```bash
   ./atm
   ```

Default PIN: `1234`  
Initial Balance: `$1000.00`

## License
MIT
